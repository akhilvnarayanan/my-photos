import { index, integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const importJobsTable = pgTable(
  "import_jobs",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    sourcePath: text("source_path").notNull(),
    status: text("status").notNull(),
    totalFiles: integer("total_files").notNull().default(0),
    processedFiles: integer("processed_files").notNull().default(0),
    successfulFiles: integer("successful_files").notNull().default(0),
    duplicateFiles: integer("duplicate_files").notNull().default(0),
    failedFiles: integer("failed_files").notNull().default(0),
    currentFile: text("current_file"),
    errors: text("errors").array().notNull().default([]),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userIdx: index("import_jobs_user_idx").on(table.userId),
    statusIdx: index("import_jobs_status_idx").on(table.status),
  }),
);

export const importFilesTable = pgTable("import_files", {
  id: text("id").primaryKey(),
  importJobId: text("import_job_id").notNull(),
  sourcePath: text("source_path").notNull(),
  destinationPath: text("destination_path"),
  status: text("status").notNull(),
  error: text("error"),
  processedAt: timestamp("processed_at", { withTimezone: true }),
});

export const insertImportJobSchema = createInsertSchema(importJobsTable).omit({
  startedAt: true,
  updatedAt: true,
});
export type InsertImportJob = z.infer<typeof insertImportJobSchema>;
export type ImportJobRecord = typeof importJobsTable.$inferSelect;
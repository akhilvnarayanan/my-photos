# My Photos

My Photos is a private, self-hosted photo library for Google Takeout archives. Originals stay on the server's filesystem; PostgreSQL stores searchable metadata, album relationships, favorites, and resumable import progress.

## What works

- Local password-protected login with secure, database-backed sessions
- Recursive Google Takeout folder scanning
- Takeout JSON metadata, capture dates, GPS coordinates, and filename parsing
- SHA-256 exact duplicate detection without storing a second physical copy
- Local original storage with generated small and medium JPEG derivatives
- Chronological timeline with lazy-loaded thumbnails, search, and photo/video filters
- Full-screen viewer with previous/next, zoom, fullscreen, download, favorite, and keyboard controls
- Album creation, rename, delete, add, and remove flows
- Favorites, GPS-grouped Places, import progress controls, import error history, and library statistics
- Responsive desktop, tablet, and mobile navigation

## Local installation

Requirements: Node.js 24, pnpm, PostgreSQL, and ffmpeg.

```bash
cp .env.example .env
pnpm install
pnpm --filter @workspace/db run push
pnpm --filter @workspace/api-server run dev
```

In a second terminal:

```bash
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/my-photos run dev
```

Open `http://localhost:5173`. Set `MY_PHOTOS_USERNAME` and `MY_PHOTOS_PASSWORD` before starting the API. The defaults in `.env.example` are intended for first-run local development only.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string |
| `PHOTO_STORAGE_PATH` | Managed filesystem root for originals and thumbnails |
| `MY_PHOTOS_USERNAME` | Local account username |
| `MY_PHOTOS_PASSWORD` | Local account password; it is hashed before storage |
| `PORT` | Port injected into each running service |
| `BASE_PATH` | Vite preview path; use `/` for the standalone app |

## Importing Google Takeout

1. Extract the Takeout archive on the same server as My Photos.
2. Sign in and open **Import archive**.
3. Enter the absolute path to the extracted `Google Photos` directory.
4. Start the import. The worker scans recursively, reads matching JSON sidecars when available, falls back to file dates when metadata is missing, hashes every file, and writes progress after each item.
5. Pause, resume, or cancel from the import dashboard. Restarting the server leaves completed records in place and skips exact duplicates.

Photos are stored as:

```text
PHOTO_STORAGE_PATH/
  originals/<year>/<id>.<extension>
  thumbnails/small/<year>/<id>.jpg
  thumbnails/medium/<year>/<id>.jpg
```

The API never exposes this directory as a static public folder. Media is delivered only through authenticated photo routes.

## PostgreSQL

The current workspace uses Drizzle ORM. Push the development schema after changing `lib/db/src/schema/`:

```bash
pnpm --filter @workspace/db run push
```

The main tables are users, sessions, photos, albums, album photos, import jobs, and import files.

## Docker Compose

The included Compose setup runs PostgreSQL, the API, and an nginx-served frontend. Photo storage is a persistent named volume.

```bash
docker compose up --build
```

Then open `http://localhost:8080` and log in with the values configured in `docker-compose.yml` or an override file.

## API and frontend development

The API contract lives in `lib/api-spec/openapi.yaml`. After changing it, regenerate the typed React Query client and Zod schemas:

```bash
pnpm --filter @workspace/api-spec run codegen
```

Useful checks:

```bash
pnpm run typecheck
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/my-photos run typecheck
```

## Production builds

```bash
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/my-photos run build
pnpm --filter @workspace/api-server run build
```

On Windows, use a local absolute `PHOTO_STORAGE_PATH` such as `D:\Photos\MyPhotos` and run PostgreSQL, ffmpeg, the API, and the Vite-built frontend as services. On Linux, use a mounted filesystem path such as `/data/photos` and keep the database and photo volume backed up separately.

## Deliberate non-goals

The MVP does not upload originals to external cloud services and does not include AI search, face recognition, sharing links, cloud sync, photo editing, stories, or automatic memories.
import path from "node:path";
import { eq } from "drizzle-orm";
import { db, albumPhotosTable, photosTable } from "@workspace/db";

export const storageRoot = path.resolve(process.env.PHOTO_STORAGE_PATH ?? path.resolve(process.cwd(), "storage"));

export function mediaResponse(photo: typeof photosTable.$inferSelect, albumIds: string[] = []) {
  const base = `/api/photos/${photo.id}`;
  return {
    id: photo.id,
    filename: photo.filename,
    thumbnailUrl: `${base}/thumbnail`,
    mediumUrl: `${base}/medium`,
    originalUrl: `${base}/original`,
    mimeType: photo.mimeType,
    mediaType: photo.mediaType as "photo" | "video",
    fileSize: photo.fileSize,
    width: photo.width,
    height: photo.height,
    captureDate: photo.captureDate,
    latitude: photo.latitude == null ? null : Number(photo.latitude),
    longitude: photo.longitude == null ? null : Number(photo.longitude),
    isFavorite: photo.isFavorite,
    albumIds,
  };
}

export async function albumIdsForPhotos(photoIds: string[]) {
  if (!photoIds.length) return new Map<string, string[]>();
  const rows = await db.select().from(albumPhotosTable);
  const result = new Map<string, string[]>();
  for (const row of rows) {
    if (photoIds.includes(row.photoId)) result.set(row.photoId, [...(result.get(row.photoId) ?? []), row.albumId]);
  }
  return result;
}

export async function albumIdsForPhoto(photoId: string) {
  const rows = await db.select({ albumId: albumPhotosTable.albumId }).from(albumPhotosTable).where(eq(albumPhotosTable.photoId, photoId));
  return rows.map((row) => row.albumId);
}
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import { createReadStream, promises as fs } from "node:fs";
import path from "node:path";
import { promisify } from "node:util";
import { and, eq } from "drizzle-orm";
import ExifReader, { type ExpandedTags } from "exifreader";
import { db, importFilesTable, importJobsTable, photosTable } from "@workspace/db";
import { logger } from "./logger";
import { storageRoot } from "./media";

const execFileAsync = promisify(execFile);
const IMAGE_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic"]);
const VIDEO_EXTENSIONS = new Set([".mp4", ".mov", ".webm", ".m4v"]);

type TakeoutMetadata = {
  title?: string;
  description?: string;
  photoTakenTime?: { timestamp?: string };
  creationTime?: { timestamp?: string };
  modificationTime?: { timestamp?: string };
  geoData?: { latitude?: number; longitude?: number };
  geoDataExif?: { latitude?: number; longitude?: number };
};

async function walk(directory: string): Promise<string[]> {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(full));
    else if (IMAGE_EXTENSIONS.has(path.extname(entry.name).toLowerCase()) || VIDEO_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) files.push(full);
  }
  return files;
}

async function readMetadata(source: string): Promise<TakeoutMetadata | null> {
  const candidates = [
    `${source}.json`,
    path.join(path.dirname(source), `${path.parse(source).name}.json`),
    `${source}.supplemental-metadata.json`,
    path.join(path.dirname(source), `${path.parse(source).name}.supplemental-metadata.json`),
  ];
  for (const candidate of candidates) {
    try {
      return JSON.parse(await fs.readFile(candidate, "utf8")) as TakeoutMetadata;
    } catch {
      // Takeout files without metadata are expected.
    }
  }
  return null;
}

function validDate(value: Date | undefined) {
  return value && !Number.isNaN(value.getTime()) ? value : undefined;
}

function dateFromTimestamp(timestamp?: string) {
  if (!timestamp) return undefined;
  const seconds = Number(timestamp);
  return Number.isFinite(seconds) ? validDate(new Date(seconds * 1000)) : undefined;
}

function dateFromExif(value: unknown) {
  if (typeof value !== "string") return undefined;
  const match = value.trim().match(/^(\d{4}):(\d{2}):(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/);
  if (!match) return undefined;
  return validDate(new Date(`${match[1]}-${match[2]}-${match[3]}T${match[4]}:${match[5]}:${match[6]}`));
}

function coordinatesFromExif(tags: ExpandedTags) {
  const latitude = tags.gps?.Latitude;
  const longitude = tags.gps?.Longitude;
  return typeof latitude === "number" && typeof longitude === "number"
    ? { latitude, longitude }
    : undefined;
}

async function readExifMetadata(source: string) {
  if (!IMAGE_EXTENSIONS.has(path.extname(source).toLowerCase())) return {};
  try {
    const tags = ExifReader.load(await fs.readFile(source), { expanded: true });
    const exif = tags.exif;
    return {
      captureDate: dateFromExif(exif?.DateTimeOriginal?.description)
        ?? dateFromExif(exif?.DateTimeDigitized?.description)
        ?? dateFromExif(exif?.DateTime?.description),
      coordinates: coordinatesFromExif(tags),
    };
  } catch {
    return {};
  }
}

async function readVideoMetadata(source: string) {
  if (!VIDEO_EXTENSIONS.has(path.extname(source).toLowerCase())) return {};
  try {
    const { stdout } = await execFileAsync("ffprobe", [
      "-v", "quiet",
      "-show_entries", "format_tags=creation_time:stream_tags=creation_time",
      "-of", "json",
      source,
    ]);
    const parsed = JSON.parse(stdout) as { format?: { tags?: { creation_time?: string } }; streams?: Array<{ tags?: { creation_time?: string } }> };
    const timestamp = parsed.format?.tags?.creation_time ?? parsed.streams?.find((stream) => stream.tags?.creation_time)?.tags?.creation_time;
    return { captureDate: timestamp ? validDate(new Date(timestamp)) : undefined };
  } catch {
    return {};
  }
}

async function sha256File(source: string) {
  const hash = crypto.createHash("sha256");
  for await (const chunk of createReadStream(source)) hash.update(chunk);
  return hash.digest("hex");
}

async function thumbnail(source: string, destination: string, width: number) {
  await fs.mkdir(path.dirname(destination), { recursive: true });
  try {
    await execFileAsync("ffmpeg", ["-y", "-loglevel", "error", "-i", source, "-vf", `scale='min(${width},iw)':-2`, "-frames:v", "1", destination]);
  } catch (error) {
    await fs.rm(destination, { force: true });
    throw error;
  }
}

export async function runImportJob(jobId: string) {
  const [job] = await db.select().from(importJobsTable).where(eq(importJobsTable.id, jobId)).limit(1);
  if (!job) return;
  let files: string[];
  try {
    files = await walk(path.resolve(job.sourcePath));
  } catch (error) {
    await db.update(importJobsTable).set({ status: "failed", errors: [`Cannot scan folder: ${String(error)}`], updatedAt: new Date() }).where(eq(importJobsTable.id, jobId));
    return;
  }

  await db.update(importJobsTable).set({ status: "importing", totalFiles: files.length, updatedAt: new Date() }).where(eq(importJobsTable.id, jobId));
  const existingFiles = await db.select({ sourcePath: importFilesTable.sourcePath }).from(importFilesTable).where(eq(importFilesTable.importJobId, jobId));
  const processedSources = new Set(existingFiles.map((file) => file.sourcePath));
  const [startingJob] = await db.select().from(importJobsTable).where(eq(importJobsTable.id, jobId)).limit(1);
  let processed = startingJob?.processedFiles ?? 0;
  for (const source of files) {
    if (processedSources.has(source)) continue;
    const [current] = await db.select().from(importJobsTable).where(eq(importJobsTable.id, jobId)).limit(1);
    if (!current || current.status === "cancelled") break;
    if (current.status === "paused") {
      await new Promise((resolve) => setTimeout(resolve, 1200));
      continue;
    }
    try {
      const digest = await sha256File(source);
      const [duplicate] = await db.select({ id: photosTable.id }).from(photosTable).where(and(eq(photosTable.userId, current.userId), eq(photosTable.hash, digest))).limit(1);
      const metadata = await readMetadata(source);
      const exif = await readExifMetadata(source);
      const embedded = await readVideoMetadata(source);
      const captureDate = dateFromTimestamp(metadata?.photoTakenTime?.timestamp)
        ?? dateFromTimestamp(metadata?.creationTime?.timestamp)
        ?? dateFromTimestamp(metadata?.modificationTime?.timestamp)
        ?? exif.captureDate
        ?? embedded.captureDate
        ?? (await fs.stat(source)).mtime;
      const geoData = [metadata?.geoData, metadata?.geoDataExif, exif.coordinates].find((value) =>
        value && typeof value.latitude === "number" && typeof value.longitude === "number"
          && Number.isFinite(value.latitude) && Number.isFinite(value.longitude)
          && (value.latitude !== 0 || value.longitude !== 0),
      ) ?? metadata?.geoData ?? metadata?.geoDataExif ?? exif.coordinates;
      if (duplicate) {
        processed += 1;
        await db.insert(importFilesTable).values({ id: crypto.randomUUID(), importJobId: jobId, sourcePath: source, destinationPath: null, status: "duplicate", processedAt: new Date() });
        processedSources.add(source);
        await db.update(importJobsTable).set({ processedFiles: processed, duplicateFiles: current.duplicateFiles + 1, currentFile: path.basename(source), updatedAt: new Date() }).where(eq(importJobsTable.id, jobId));
        continue;
      }
      const id = crypto.randomUUID();
      const ext = path.extname(source).toLowerCase();
      const mediaType = VIDEO_EXTENSIONS.has(ext) ? "video" : "photo";
      const year = captureDate.getUTCFullYear().toString();
      const originalPath = path.join(storageRoot, "originals", year, `${id}${ext}`);
      const smallPath = path.join(storageRoot, "thumbnails", "small", year, `${id}.jpg`);
      const mediumPath = path.join(storageRoot, "thumbnails", "medium", year, `${id}.jpg`);
      await fs.mkdir(path.dirname(originalPath), { recursive: true });
      await fs.copyFile(source, originalPath);
      await Promise.all([thumbnail(source, smallPath, 260), thumbnail(source, mediumPath, 1100)]);
      const stat = await fs.stat(source);
      const [inserted] = await db.insert(photosTable).values({
        id,
        userId: current.userId,
        filename: metadata?.title || path.basename(source),
        originalPath,
        thumbnailSmallPath: smallPath,
        thumbnailMediumPath: mediumPath,
        mimeType: mediaType === "video" ? `video/${ext.slice(1)}` : `image/${ext === ".jpg" ? "jpeg" : ext.slice(1)}`,
        mediaType,
        fileSize: stat.size,
        captureDate,
        latitude: geoData?.latitude?.toString(),
        longitude: geoData?.longitude?.toString(),
        hash: digest,
      }).returning();
      await db.insert(importFilesTable).values({ id: crypto.randomUUID(), importJobId: jobId, sourcePath: source, destinationPath: inserted.originalPath, status: "completed", processedAt: new Date() });
      processedSources.add(source);
      processed += 1;
      await db.update(importJobsTable).set({ processedFiles: processed, successfulFiles: current.successfulFiles + 1, currentFile: path.basename(source), updatedAt: new Date() }).where(eq(importJobsTable.id, jobId));
    } catch (error) {
      processed += 1;
      await db.insert(importFilesTable).values({ id: crypto.randomUUID(), importJobId: jobId, sourcePath: source, destinationPath: null, status: "failed", error: String(error), processedAt: new Date() });
      processedSources.add(source);
      await db.update(importJobsTable).set({ processedFiles: processed, failedFiles: current.failedFiles + 1, currentFile: path.basename(source), errors: [...current.errors, `${path.basename(source)}: ${String(error)}`], updatedAt: new Date() }).where(eq(importJobsTable.id, jobId));
      logger.warn({ source, error }, "Import file failed");
    }
  }
  const [finished] = await db.select().from(importJobsTable).where(eq(importJobsTable.id, jobId)).limit(1);
  if (finished && finished.status !== "cancelled") {
    await db.update(importJobsTable).set({ status: finished.processedFiles >= finished.totalFiles ? "completed" : finished.status, updatedAt: new Date() }).where(eq(importJobsTable.id, jobId));
  }
  logger.info({ jobId }, "Import completed");
}
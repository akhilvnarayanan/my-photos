import app from "./app";
import { logger } from "./lib/logger";
import { db, importJobsTable } from "@workspace/db";
import { inArray } from "drizzle-orm";
import { runImportJob } from "./lib/importer";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  void db.select({ id: importJobsTable.id }).from(importJobsTable)
    .where(inArray(importJobsTable.status, ["scanning", "importing"]))
    .then((jobs) => Promise.all(jobs.map((job) => runImportJob(job.id))))
    .catch((error) => logger.error({ error }, "Failed to resume imports"));
});

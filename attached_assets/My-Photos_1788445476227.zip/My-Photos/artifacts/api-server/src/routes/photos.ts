import { Router, type IRouter } from "express";
import { and, desc, eq, gte, ilike, lt, lte, or, sql } from "drizzle-orm";
import { db, albumPhotosTable, photosTable } from "@workspace/db";
import { DeletePhotoParams, DownloadPhotoParams, GetPhotoParams, ListPhotosQueryParams, ListPhotosResponse, ToggleFavoriteBody, ToggleFavoriteParams, ToggleFavoriteResponse } from "@workspace/api-zod";
import { requireUser } from "../lib/auth";
import { albumIdsForPhoto, albumIdsForPhotos, mediaResponse } from "../lib/media";
import { promises as fs } from "node:fs";

const router: IRouter = Router();
router.use("/photos", requireUser);

router.get("/photos", async (req, res): Promise<void> => {
  const parsed = ListPhotosQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const query = parsed.data;
  const userId = res.locals.user.userId as string;
  const filters = [eq(photosTable.userId, userId)];
  if (query.query) filters.push(ilike(photosTable.filename, `%${query.query}%`));
  if (query.mediaType !== "all") filters.push(eq(photosTable.mediaType, query.mediaType));
  if (query.favorite !== undefined) filters.push(eq(photosTable.isFavorite, query.favorite));
  if (query.year) {
    filters.push(gte(photosTable.captureDate, new Date(Date.UTC(query.year, (query.month ?? 1) - 1, 1))));
    filters.push(lt(photosTable.captureDate, query.month
      ? new Date(Date.UTC(query.year, query.month, 1))
      : new Date(Date.UTC(query.year + 1, 0, 1))));
  }
  if (query.from) filters.push(gte(photosTable.captureDate, query.from));
  if (query.to) filters.push(lte(photosTable.captureDate, query.to));
  const countFilters = [...filters];
  if (query.cursor) {
    const [cursorDateText, cursorId] = query.cursor.split("|");
    const cursorDate = new Date(cursorDateText);
    if (!Number.isNaN(cursorDate.getTime()) && cursorId) {
      const cursorFilter = or(
        lt(photosTable.captureDate, cursorDate),
        and(eq(photosTable.captureDate, cursorDate), lt(photosTable.id, cursorId)),
      );
      if (cursorFilter) filters.push(cursorFilter);
    } else if (!Number.isNaN(cursorDate.getTime())) {
      filters.push(lt(photosTable.captureDate, cursorDate));
    }
  }
  if (query.albumId) filters.push(sql`exists (select 1 from album_photos where album_photos.album_id = ${query.albumId} and album_photos.photo_id = ${photosTable.id})`);
  if (query.albumId) countFilters.push(sql`exists (select 1 from album_photos where album_photos.album_id = ${query.albumId} and album_photos.photo_id = ${photosTable.id})`);
  const rows = await db.select().from(photosTable).where(and(...filters)).orderBy(desc(photosTable.captureDate), desc(photosTable.id)).limit(query.limit + 1);
  const hasNext = rows.length > query.limit;
  const pageRows = rows.slice(0, query.limit);
  const albumMap = await albumIdsForPhotos(pageRows.map((row) => row.id));
  const [count] = await db.select({ count: sql<number>`count(*)` }).from(photosTable).where(and(...countFilters));
  const response = {
    items: pageRows.map((row) => mediaResponse(row, albumMap.get(row.id) ?? [])),
    nextCursor: hasNext ? `${pageRows.at(-1)?.captureDate.toISOString()}|${pageRows.at(-1)?.id}` : null,
    total: Number(count?.count ?? 0),
  };
  res.json(ListPhotosResponse.parse(response));
});

router.get("/photos/:photoId", async (req, res): Promise<void> => {
  const parsed = GetPhotoParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [photo] = await db.select().from(photosTable).where(and(eq(photosTable.id, parsed.data.photoId), eq(photosTable.userId, res.locals.user.userId))).limit(1);
  if (!photo) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }
  res.json(mediaResponse(photo, await albumIdsForPhoto(photo.id)));
});

router.get("/photos/:photoId/:variant", async (req, res): Promise<void> => {
  const parsed = GetPhotoParams.safeParse(req.params);
  const variant = req.params.variant;
  if (!parsed.success || !["thumbnail", "medium", "original", "download"].includes(variant)) {
    res.status(400).json({ error: "Invalid media request" });
    return;
  }
  const [photo] = await db.select().from(photosTable).where(and(eq(photosTable.id, parsed.data.photoId), eq(photosTable.userId, res.locals.user.userId))).limit(1);
  if (!photo) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }
  const filePath = variant === "original" || variant === "download" ? photo.originalPath : variant === "medium" ? photo.thumbnailMediumPath : photo.thumbnailSmallPath;
  if (!filePath) {
    res.status(404).json({ error: "Media derivative not available" });
    return;
  }
  try {
    await fs.access(filePath);
    if (variant === "download") res.download(filePath, photo.filename);
    else res.sendFile(filePath);
  } catch {
    res.status(404).json({ error: "Media file not found" });
  }
});

router.get("/photos/:photoId/download", async (req, res): Promise<void> => {
  const parsed = DownloadPhotoParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [photo] = await db.select().from(photosTable).where(and(eq(photosTable.id, parsed.data.photoId), eq(photosTable.userId, res.locals.user.userId))).limit(1);
  if (!photo) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }
  try {
    await fs.access(photo.originalPath);
    res.download(photo.originalPath, photo.filename);
  } catch {
    res.status(404).json({ error: "Original file not found" });
  }
});

router.delete("/photos/:photoId", async (req, res): Promise<void> => {
  const parsed = DeletePhotoParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [photo] = await db.delete(photosTable).where(and(eq(photosTable.id, parsed.data.photoId), eq(photosTable.userId, res.locals.user.userId))).returning();
  if (!photo) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }
  await Promise.all([photo.originalPath, photo.thumbnailSmallPath, photo.thumbnailMediumPath].filter(Boolean).map((file) => fs.rm(file as string, { force: true })));
  res.sendStatus(204);
});

router.patch("/photos/:photoId/favorite", async (req, res): Promise<void> => {
  const params = ToggleFavoriteParams.safeParse(req.params);
  const body = ToggleFavoriteBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [photo] = await db.update(photosTable).set({ isFavorite: body.data.isFavorite, updatedAt: new Date() }).where(and(eq(photosTable.id, params.data.photoId), eq(photosTable.userId, res.locals.user.userId))).returning();
  if (!photo) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }
  res.json(ToggleFavoriteResponse.parse(mediaResponse(photo, await albumIdsForPhoto(photo.id))));
});

export default router;
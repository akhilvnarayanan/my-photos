import { Router, type IRouter, type Request, type Response } from "express";
import crypto from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import { db, importJobsTable } from "@workspace/db";
import { CancelImportParams, CancelImportResponse, GetImportParams, GetImportResponse, ListImportsResponse, PauseImportParams, PauseImportResponse, ResumeImportParams, ResumeImportResponse, StartImportBody, StartImportResponse } from "@workspace/api-zod";
import { requireUser } from "../lib/auth";
import { runImportJob } from "../lib/importer";

const router: IRouter = Router();
router.use("/imports", requireUser);

function importResponse(job: typeof importJobsTable.$inferSelect) {
  return {
    id: job.id,
    sourcePath: job.sourcePath,
    status: job.status as "scanning" | "importing" | "paused" | "completed" | "cancelled" | "failed",
    totalFiles: job.totalFiles,
    processedFiles: job.processedFiles,
    successfulFiles: job.successfulFiles,
    duplicateFiles: job.duplicateFiles,
    failedFiles: job.failedFiles,
    currentFile: job.currentFile,
    errors: job.errors,
    startedAt: job.startedAt,
    updatedAt: job.updatedAt,
  };
}

router.get("/imports", async (_req, res): Promise<void> => {
  const rows = await db.select().from(importJobsTable).where(eq(importJobsTable.userId, res.locals.user.userId)).orderBy(desc(importJobsTable.updatedAt)).limit(20);
  res.json(ListImportsResponse.parse(rows.map(importResponse)));
});

router.post("/imports", async (req, res): Promise<void> => {
  const parsed = StartImportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [job] = await db.insert(importJobsTable).values({ id: crypto.randomUUID(), userId: res.locals.user.userId, sourcePath: parsed.data.sourcePath, status: "scanning" }).returning();
  void runImportJob(job.id);
  res.status(202).json(StartImportResponse.parse(importResponse(job)));
});

router.get("/imports/:importId", async (req, res): Promise<void> => {
  const parsed = GetImportParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [job] = await db.select().from(importJobsTable).where(and(eq(importJobsTable.id, parsed.data.importId), eq(importJobsTable.userId, res.locals.user.userId))).limit(1);
  if (!job) {
    res.status(404).json({ error: "Import not found" });
    return;
  }
  res.json(GetImportResponse.parse(importResponse(job)));
});

async function setImportStatus(req: Request, res: Response, status: string, schema: typeof PauseImportResponse | typeof ResumeImportResponse | typeof CancelImportResponse): Promise<void> {
  const parsed = (status === "paused" ? PauseImportParams : status === "importing" ? ResumeImportParams : CancelImportParams).safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [job] = await db.update(importJobsTable).set({ status, updatedAt: new Date() }).where(and(eq(importJobsTable.id, parsed.data.importId), eq(importJobsTable.userId, res.locals.user.userId))).returning();
  if (!job) {
    res.status(404).json({ error: "Import not found" });
    return;
  }
  res.json(schema.parse(importResponse(job)));
}

router.post("/imports/:importId/pause", async (req, res): Promise<void> => { await setImportStatus(req, res, "paused", PauseImportResponse); });
router.post("/imports/:importId/resume", async (req, res): Promise<void> => { await setImportStatus(req, res, "importing", ResumeImportResponse); });
router.post("/imports/:importId/cancel", async (req, res): Promise<void> => { await setImportStatus(req, res, "cancelled", CancelImportResponse); });

export default router;